package Layan;

import java.util.ArrayList;
import java.util.List;

public class LibraryData { 
    //<book> is from class BOOK
    private List<Book> books;    //attribute books  for the librarydata class , books is an object of listbook class    

    public LibraryData(List<Book> bookss) {
        books = bookss;
    }

    public List<Book> getBooks() { // for the gui 
        return books;
    }

    public void setBooks(List<Book> bookss) {
        books = bookss;
    }

    public List<String> getCategories() { // return  string ; categories are strings  
        List<String> categories = new ArrayList<>(); // for categories names  to filter books based in catogry of type string 
        for (Book book : books) {
            String category = book.getCategory();
            if (!categories.contains(category)) {
                categories.add(category);
            }
        }
        return categories;
    }
}