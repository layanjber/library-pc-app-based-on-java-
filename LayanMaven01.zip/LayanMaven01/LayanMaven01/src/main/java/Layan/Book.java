package Layan;

public class Book {
    private final String isbn;
    private final String title;
    private final String category;
    private final String downloadLink;
    private final String bookCover; // for the bookCover path

    public Book(String isbnn, String titlee, String categoryy, String downloadLinkk, String bookCoverr) {
        isbn = isbnn;
        title = titlee;
        category = categoryy;
        downloadLink = downloadLinkk;
        bookCover = bookCoverr;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getDownloadLink() {
        return downloadLink;
    }

    public String getBookCover() {
        return bookCover;
    }
}