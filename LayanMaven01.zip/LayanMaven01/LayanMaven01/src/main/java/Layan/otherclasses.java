/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Layan;

/**
 *
 * @author Dell
 */


// Abstract class representing a MediaItem
abstract class MediaItem {
    private final String title;
    private final int year;

    public MediaItem(String title, int year) {
        this.title = title;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    // Abstract method to be implemented by subclasses
    public abstract void play();
}

// Interface for DVD items
interface DVD {
    void playDVD();
}

// Interface for audio items
interface Audio {
    void playAudio();
}

// MovieDVD class implementing DVD interface
class MovieDVD extends MediaItem implements DVD {
    public MovieDVD(String title, int year) {
        super(title, year);
    }

    @Override
    public void play() {
        System.out.println("Playing movie: " + getTitle());
    }

    @Override
    public void playDVD() {
        System.out.println("Playing DVD: " + getTitle());
    }
}

// Podcast class implementing Audio interface
class Podcast extends MediaItem implements Audio {
    public Podcast(String title, int year) {
        super(title, year);
    }

    @Override
    public void play() {
        System.out.println("Playing podcast: " + getTitle());
    }

    @Override
    public void playAudio() {
        System.out.println("Playing audio: " + getTitle());
    }
}

// Music class implementing Audio interface
class Music extends MediaItem implements Audio {
    public Music(String title, int year) {
        super(title, year);
    }

    @Override
    public void play() {
        System.out.println("Playing music: " + getTitle());
    }

    @Override
    public void playAudio() {
        System.out.println("Playing audio: " + getTitle());
    }
}

// Main class for demonstration (not affected by the additional classes)
public class otherclasses {
    
}
