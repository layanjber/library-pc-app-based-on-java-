package Layan;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import javax.swing.JOptionPane;

import java.util.ArrayList;
import com.google.gson.Gson;

//This means that Library inherits all the properties and methods of the LibraryData class.
public class Library extends LibraryData {
    private String databaseFilePath;

    public Library(String databaseFilePathh) {
        super(new ArrayList<>());
        databaseFilePath = databaseFilePathh;
        loadDatabase();
    }

    private void loadDatabase() {
        Gson gson = new Gson();
        try (Reader reader = new FileReader(databaseFilePath)) { // try cause maybe the db is empty 
            LibraryData libraryData = gson.fromJson(reader, LibraryData.class); // Parsing the json file into LibraryData object
            
            setBooks( libraryData.getBooks());
            
        } catch (IOException error) {
            error.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading database: " + error.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

