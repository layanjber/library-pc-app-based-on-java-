package Layan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.awt.*;
import java.awt.event.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.HashMap;
import java.util.Map;
// Swing and AWT classes are imported for creating GUI components and handling events.


public class LibrarySystemGUI extends JFrame {
    //This class extends JFrame  that  represents a GUI window.
    private Library library;  // object to the library system
    
    private JTable table;               // object Table for displaying books
    private JComboBox<String> categoryComboBox; 
    private JTextField searchField;
    private JButton searchButton;
    private DefaultTableModel tableModel;
    private Map<String, ImageIcon> imageCache;
//The constructor initializes the library with a database file named "library_database.json" and it initializes the imageCache
    public LibrarySystemGUI() {
        library = new Library("library_database.json"); // assign ( database file path)libbrary object inside the construct 
        imageCache = new HashMap<>(); //  the image cache
        initializeUI();// Setting up the user interface
    }
    //Then, it calls the initializeUI() method to set up the user interface.
    
    /* private Password Checker Method: */
    
    private static boolean passwordChecker(JFrame parent) {
        // set a dialog box for the user to enter a password. It returns true if the password entered is correct then open the library window 
        JDialog dialog = new JDialog(parent, "Login Page", true); //the dialog name 
      // Panel Setup:
        JPanel panel = new JPanel(new BorderLayout(10, 10)); //
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dialog.setContentPane(panel);
           //Components such as JLabel, JTextField, and JButton are created.
 //The label is added to the north, the text field to the center, and the button to the south of the panel.
        JLabel promptLabel = new JLabel("Please enter the Password:");
        panel.add(promptLabel, BorderLayout.NORTH);
// the text field to the center
        JTextField numberField = new JTextField();
        panel.add(numberField, BorderLayout.CENTER);
// and the button  ok to the south of the panel
        JButton okButton = new JButton("OK");
        panel.add(okButton, BorderLayout.SOUTH);
            // array success is used to store the success status of password verification.
        final boolean[] success = {false};  
        //action listener is added to the OK button.
            okButton.addActionListener(e -> {
           
                if (numberField.getText().trim().equals("1233")) {
                    success[0] = true;
                    dialog.dispose();  //it  display/ go to the window 
                } else {
                    JOptionPane.showMessageDialog(dialog, "Incorrect Password. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    numberField.setText(""); //it cleans the prev text and print the massage
                }
            });

        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);  // Make the dialog visible

        return success[0];
    }
    // setting the fram <libbray fram windo >
    private void initializeUI() {
        setTitle("Layan Library");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(mainPanel);

        // Top panel for categories and search bar
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Categories dropdown
        JPanel categoryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel categoryLabel = new JLabel("Categories:");
        categoryComboBox = new JComboBox<>();
        categoryComboBox.addItem("All");
        List<String> categories = library.getCategories(); 
// call the method to show the catogries in class libbray 
        for (String category : categories) {
            categoryComboBox.addItem(category);
        }
        categoryPanel.add(categoryLabel); 
        categoryPanel.add(categoryComboBox);
        topPanel.add(categoryPanel, BorderLayout.WEST);

        // Search bar
        JPanel searchPanel = new JPanel(new BorderLayout(10, 10));
        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchButton = new JButton("Search");
        searchButton.setPreferredSize(new Dimension(80, 30));
        searchPanel.add(searchField, BorderLayout.CENTER); //to enter serach keywords
        searchPanel.add(searchButton, BorderLayout.EAST); //button to enter search
        topPanel.add(searchPanel, BorderLayout.CENTER);

        // Table for displaying books
        String[] columnNames = {"ISBN", "Cover", "Title", "Category", "Download"};
        // an array named columnnames for the table 
        tableModel = new DefaultTableModel(columnNames, 0) {
            // uesing override to make sure we cant edit the cells 
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        // table 
        table = new JTable(tableModel) {
            @Override
            
            public Class<?> getColumnClass(int column) {
                if (column == 1) {
                    return ImageIcon.class;
                }
                return String.class;
            }

            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component component = super.prepareRenderer(renderer, row, column);
                if (column == 1) {
                    JLabel label = (JLabel) component;
                    label.setHorizontalAlignment(JLabel.CENTER);
                    label.setBorder(new EmptyBorder(5, 5, 5, 5));
                }
                if (column == 2) {
                    JLabel label = (JLabel) component;
                    label.setHorizontalAlignment(JLabel.CENTER);
                    label.setBorder(new EmptyBorder(5, 5, 5, 5));
                }
                return component;
            }
        };
        
        table.getTableHeader().setReorderingAllowed(false);
        table.setRowHeight(100);
        JScrollPane scrollPane = new JScrollPane(table); //to hold the table
        mainPanel.add(scrollPane, BorderLayout.CENTER); // to scroll throw the window 

        // Populate table with initial data , filling the table with the data from book library 
        populateTable(library.getBooks());

        // Add search button action listener
        searchButton.addActionListener(e -> performSearch());

        // Add category combo box action listener
        categoryComboBox.addActionListener(e -> performSearch());

        // Add key listener to the search field
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });

        // Add mouse listener to the table to handle clicks on the download button
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int column = table.getColumnModel().getColumnIndexAtX(e.getX());
                int row = e.getY() / table.getRowHeight();

                if (row < table.getRowCount() && row >= 0 && column < table.getColumnCount() && column >= 0) {
                    if (table.getValueAt(row, column).equals("Download")) {
                        Book book = (library.getBooks()).get(row);
                        String coverpath = book.getDownloadLink();

                        try { // opening a URL in the default web browser using
                            Desktop.getDesktop().browse(new URI(coverpath));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Error opening download link: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });
    }

    private void performSearch() {
        String keyword = searchField.getText().trim().toLowerCase();
        String selectedCategory = (String) categoryComboBox.getSelectedItem();
        List<Book> books;

        if (selectedCategory.equals("All")) {
            books = library.getBooks();
        } else {
            books = library.getBooks().stream()
                    .filter(book -> book.getCategory().equalsIgnoreCase(selectedCategory))
                    .collect(Collectors.toList());
        }

        List<Book> filteredBooks = books.stream()
                .filter(book -> book.getIsbn().toLowerCase().contains(keyword) || book.getTitle().toLowerCase().contains(keyword))
                .collect(Collectors.toList());

        populateTable(filteredBooks);
    }

    private void populateTable(List<Book> books) {
        tableModel.setRowCount(0);

        for (Book book : books) {
            ImageIcon pictureIcon = imageCache.get(book.getBookCover());
            if (pictureIcon == null) {
                pictureIcon = new ImageIcon();
                loadAndCacheImage(book.getBookCover(), pictureIcon);
            }
            Object[] row = {book.getIsbn(), pictureIcon, book.getTitle(), book.getCategory(), "Download"};
            tableModel.addRow(row);
        }
    }

    private void loadAndCacheImage(String picturePath, ImageIcon placeholder) {
        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                try {
                    // Use the file path directly to create the ImageIcon
                    ImageIcon icon = new ImageIcon(picturePath);
                    int newWidth = 70; // Adjust width for proper padding
                    int newHeight = 100;//(int) (((double) newWidth / icon.getIconWidth()) * icon.getIconHeight());
                    Image image = icon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
                    icon = new ImageIcon(image);
                    imageCache.put(picturePath, icon); // Cache the image
                    return icon;
                } catch (Exception e) {
                    e.printStackTrace();
                    return new ImageIcon(); // Fallback to empty icon if there's an error
                }
            }

            @Override
            protected void done() {
                try {
                    placeholder.setImage(get().getImage());
                    table.repaint();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }.execute();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error setting Look and Feel: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            JFrame parent = new JFrame();
            boolean isPasswordCorrect = passwordChecker(parent); // it calls the function 
            parent.dispose();

            if (isPasswordCorrect) { 
                LibrarySystemGUI gui = new LibrarySystemGUI(); // it call the class witth it own method
                gui.setVisible(true);
            } else {
                System.exit(0);
            }
        });
    }
}
